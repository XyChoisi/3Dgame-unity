﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupCollide : MonoBehaviour
{
    void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.tag == "Player" && this.gameObject.activeSelf)
        {
            this.gameObject.SetActive(false);
            //减少面包数量
            Singleton<GameEventManager>.Instance.ReduceCrystalNum();
        }
    }
}
